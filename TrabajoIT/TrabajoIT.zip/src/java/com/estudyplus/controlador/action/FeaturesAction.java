/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.estudyplus.controlador.action;

import com.opensymphony.xwork2.ActionSupport;

/**
 *
 * @author Parri
 */
public class FeaturesAction extends ActionSupport {
    @Override
    public String execute() {
        return SUCCESS;
    }
}
